package com.siec_acc.exceptions;

public class VendorNotFoundException extends RuntimeException{

    public VendorNotFoundException( String message){
        super(message);
    }
}
